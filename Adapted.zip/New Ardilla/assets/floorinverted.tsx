<?xml version="1.0" encoding="UTF-8"?>
<tileset name="floorinverted" tilewidth="16" tileheight="16" tilecount="18" columns="6">
 <image source="floorinverted.png" width="96" height="48"/>
</tileset>
